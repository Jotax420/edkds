import { createContext, useCallback, useState } from 'react';

export interface Purchase {
  id: string;
  name: string;
  region: string;
  product: string;
  timestamp: Date;
}

interface NotificationContextType {
  purchases: Purchase[];
  addPurchase: (purchase: Omit<Purchase, 'id'>) => void;
  removePurchase: (id: string) => void;
}

export const NotificationContext = createContext<NotificationContextType>({
  purchases: [],
  addPurchase: () => {},
  removePurchase: () => {},
});

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [purchases, setPurchases] = useState<Purchase[]>([]);

  const addPurchase = useCallback((purchase: Omit<Purchase, 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setPurchases(prev => [...prev, { ...purchase, id }]);

    setTimeout(() => {
      removePurchase(id);
    }, 5000);
  }, []);

  const removePurchase = useCallback((id: string) => {
    setPurchases(prev => prev.filter(p => p.id !== id));
  }, []);

  return (
    <NotificationContext.Provider value={{ purchases, addPurchase, removePurchase }}>
      {children}
    </NotificationContext.Provider>
  );
}
