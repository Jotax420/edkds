import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { NotificationCenter } from "@/components/NotificationCenter";

// Pages
import Home from "@/pages/Home";
import Products from "@/pages/Products";
import ProductDetail from "@/pages/ProductDetail";
import Contact from "@/pages/Contact";
import About from "@/pages/About";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";
import { useNotifications } from "@/hooks/use-notifications";
import { generateMockPurchase } from "@/lib/mock-purchases";

// Scroll to top on route change
function ScrollToTop() {
  const isBrowser = typeof window !== "undefined";
  if (!isBrowser) return null;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [window.location.pathname]);
  
  return null;
}

function PurchaseSimulator() {
  const { addPurchase } = useNotifications();

  useEffect(() => {
    const timer = setInterval(() => {
      addPurchase(generateMockPurchase());
    }, 8000);

    return () => clearInterval(timer);
  }, [addPurchase]);

  return null;
}

function Router() {
  return (
    <div className="flex flex-col min-h-screen font-sans">
      <ScrollToTop />
      <PurchaseSimulator />
      <Navigation />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/produtos" component={Products} />
          <Route path="/produtos/:id" component={ProductDetail} />
          <Route path="/contato" component={Contact} />
          <Route path="/sobre" component={About} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <NotificationProvider>
          <Toaster />
          <NotificationCenter />
          <Router />
        </NotificationProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
