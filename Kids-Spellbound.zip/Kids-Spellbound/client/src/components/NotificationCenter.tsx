import { useNotifications } from '@/hooks/use-notifications';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Clock, ShoppingBag } from 'lucide-react';

export function NotificationCenter() {
  const { purchases } = useNotifications();

  return (
    <div className="fixed top-6 right-6 z-[9999] flex flex-col gap-3 pointer-events-none">
      <AnimatePresence mode="popLayout">
        {purchases.map((purchase) => (
          <motion.div
            key={purchase.id}
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="pointer-events-auto"
          >
            <div className="bg-white rounded-2xl p-4 shadow-xl border border-green-200 max-w-xs">
              <div className="space-y-2">
                <div className="font-bold text-foreground text-sm">
                  ✅ Compra confirmada!
                </div>
                <div className="text-sm font-semibold text-primary">
                  {purchase.name}
                </div>
                <div className="flex items-center gap-2 text-xs text-accent font-medium bg-accent/10 px-2 py-1 rounded-lg">
                  <ShoppingBag className="w-3 h-3" />
                  <span>{purchase.product}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <MapPin className="w-3 h-3" />
                  <span>{purchase.region}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>
                    {purchase.timestamp.toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
