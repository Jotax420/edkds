import { Link } from "wouter";
import { BookOpen, Instagram, Facebook, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary/5 pt-16 pb-8 mt-auto border-t border-primary/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="font-display text-xl font-bold text-primary">
                Ortografia<span className="text-secondary">Divertida</span>
              </span>
            </Link>
            <p className="text-muted-foreground max-w-sm text-lg leading-relaxed">
              Transformando o aprendizado da ortografia em uma aventura divertida para crianças. 
              Materiais educativos criados com amor e pedagogia.
            </p>
          </div>
          
          <div>
            <h3 className="font-display text-lg font-bold mb-4 text-foreground">Links Rápidos</h3>
            <ul className="space-y-3">
              <li><Link href="/produtos" className="text-muted-foreground hover:text-primary transition-colors">Nossos Produtos</Link></li>
              <li><Link href="/sobre" className="text-muted-foreground hover:text-primary transition-colors">Sobre a Metodologia</Link></li>
              <li><Link href="/contato" className="text-muted-foreground hover:text-primary transition-colors">Fale Conosco</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-display text-lg font-bold mb-4 text-foreground">Redes Sociais</h3>
            <div className="flex gap-4">
              <a href="#" className="bg-white p-2 rounded-full shadow-sm hover:shadow-md hover:scale-110 transition-all text-pink-500">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white p-2 rounded-full shadow-sm hover:shadow-md hover:scale-110 transition-all text-blue-600">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="mailto:contato@ortografiacriativa.com" className="bg-white p-2 rounded-full shadow-sm hover:shadow-md hover:scale-110 transition-all text-primary">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary/10 pt-8 text-center text-muted-foreground">
          <p>© {new Date().getFullYear()} Ortografia Divertida. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
