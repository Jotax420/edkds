import { Link } from "wouter";
import { type Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ShoppingBag, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export function ProductCard({ product }: { product: Product }) {
  const priceFormatted = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(product.price / 100);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative bg-card rounded-3xl overflow-hidden border border-border shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
    >
      <div className="aspect-[4/3] overflow-hidden bg-muted relative flex items-center justify-center">
        <img 
          src={product.imageUrl} 
          alt={product.title}
          className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-4 py-1 rounded-full font-bold text-primary shadow-sm">
          {priceFormatted}
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="font-display text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
          {product.title}
        </h3>
        <p className="text-muted-foreground mb-6 line-clamp-2 text-sm leading-relaxed">
          {product.description}
        </p>
        
        <div className="flex items-center gap-3">
          <Link href={`/produtos/${product.id}`} className="flex-1">
            <Button className="w-full bg-secondary text-secondary-foreground font-bold hover:bg-secondary/90 rounded-xl shadow-md shadow-secondary/10">
              Ver Detalhes <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
