const NAMES = [
  'Maria Silva',
  'João Santos',
  'Ana Costa',
  'Pedro Oliveira',
  'Carla Ferreira',
  'Lucas Gomes',
  'Fernanda Rocha',
  'Roberto Alves',
  'Patricia Souza',
  'André Martins',
  'Beatriz Mendes',
  'Felipe Ribeiro',
  'Juliana Dias',
  'Marcos Teixeira',
  'Vanessa Nunes',
];

const REGIONS = [
  'São Paulo, SP',
  'Rio de Janeiro, RJ',
  'Belo Horizonte, MG',
  'Brasília, DF',
  'Salvador, BA',
  'Fortaleza, CE',
  'Manaus, AM',
  'Recife, PE',
  'Porto Alegre, RS',
  'Curitiba, PR',
  'Goiânia, GO',
  'Belém, PA',
  'Guarulhos, SP',
  'Campinas, SP',
  'Santos, SP',
];

const PRODUCTS = [
  '+300 Atividades Educação Infantil',
  '+200 Dinâmicas Ortografia',
];

export function getRandomName(): string {
  return NAMES[Math.floor(Math.random() * NAMES.length)];
}

export function getRandomRegion(): string {
  return REGIONS[Math.floor(Math.random() * REGIONS.length)];
}

export function getRandomProduct(): string {
  return PRODUCTS[Math.floor(Math.random() * PRODUCTS.length)];
}

export function generateMockPurchase() {
  return {
    name: getRandomName(),
    region: getRandomRegion(),
    product: getRandomProduct(),
    timestamp: new Date(),
  };
}
