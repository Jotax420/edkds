import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";

export default function Products() {
  const { data: products, isLoading } = useProducts();

  return (
    <div className="min-h-screen py-12 md:py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Nossos Materiais
          </h1>
          <p className="text-xl text-muted-foreground">
            Explore nossa coleção de dinâmicas, jogos e atividades focadas no desenvolvimento ortográfico divertido.
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products?.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        )}

        {products?.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <p className="text-xl">Nenhum produto encontrado no momento.</p>
          </div>
        )}
      </div>
    </div>
  );
}
