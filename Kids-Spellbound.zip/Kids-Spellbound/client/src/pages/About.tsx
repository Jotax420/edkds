import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Sparkles, Brain, Smile, CheckCircle } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="pt-20 pb-32 bg-primary/5">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-5xl md:text-6xl font-bold mb-8 text-foreground">
            Nossa Metodologia
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Acreditamos que a ortografia não precisa ser um pesadelo de regras e exceções. 
            Desenvolvemos uma abordagem que une neurociência e ludicidade.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="-mt-20 pb-20">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-[3rem] p-8 md:p-16 shadow-xl border border-border">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-20">
              <div>
                <h2 className="font-display text-3xl font-bold mb-6 text-primary">O poder do lúdico</h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Quando uma criança brinca, seu cérebro está altamente engajado e aberto a novas conexões. 
                  Nossas atividades utilizam jogos, desafios visuais e narrativas para contextualizar as palavras.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Ao invés de decorar que "casa é com s", a criança vivencia essa palavra em um contexto 
                  que faz sentido e cria uma memória afetiva duradoura.
                </p>
              </div>
              <div className="relative">
                <div className="aspect-[4/3] rounded-3xl overflow-hidden bg-muted shadow-lg transform rotate-2 hover:rotate-0 transition-all duration-500">
                  {/* teacher helping student - visual learning */}
                  <img 
                    src="https://images.unsplash.com/photo-1577896851231-70ef18881754?q=80&w=1000&auto=format&fit=crop" 
                    alt="Aprendizado visual"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-secondary p-4 rounded-2xl shadow-lg">
                  <Sparkles className="w-8 h-8 text-secondary-foreground" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
              <div className="p-8 rounded-3xl bg-blue-50 border border-blue-100">
                <Brain className="w-10 h-10 text-primary mb-4" />
                <h3 className="font-display text-xl font-bold mb-3">Neurociência</h3>
                <p className="text-muted-foreground">Atividades desenhadas para estimular diferentes áreas do cérebro simultaneamente.</p>
              </div>
              <div className="p-8 rounded-3xl bg-yellow-50 border border-yellow-100">
                <Smile className="w-10 h-10 text-yellow-600 mb-4" />
                <h3 className="font-display text-xl font-bold mb-3">Emoção Positiva</h3>
                <p className="text-muted-foreground">O aprendizado associado a emoções positivas é fixado mais profundamente.</p>
              </div>
              <div className="p-8 rounded-3xl bg-green-50 border border-green-100">
                <CheckCircle className="w-10 h-10 text-green-600 mb-4" />
                <h3 className="font-display text-xl font-bold mb-3">Autonomia</h3>
                <p className="text-muted-foreground">A criança se sente capaz e protagonista do seu próprio processo de descoberta.</p>
              </div>
            </div>

            <div className="text-center bg-foreground text-white rounded-3xl p-12 relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="font-display text-3xl font-bold mb-6">Comece hoje mesmo</h2>
                <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
                  Não espere mais para transformar a relação do seu filho ou aluno com a escrita.
                </p>
                <Link href="/produtos">
                  <Button size="lg" className="bg-white text-foreground hover:bg-gray-100 font-bold px-10 py-6 text-lg rounded-full">
                    Ver Materiais Disponíveis
                  </Button>
                </Link>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/30 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/30 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
