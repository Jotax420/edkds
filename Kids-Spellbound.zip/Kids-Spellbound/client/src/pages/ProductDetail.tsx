import { useProduct } from "@/hooks/use-products";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Loader2, Check, ShoppingBag, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function ProductDetail() {
  const [, params] = useRoute("/produtos/:id");
  const id = parseInt(params?.id || "0");
  const { data: product, isLoading, error } = useProduct(id);

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen flex flex-col justify-center items-center gap-4">
        <h2 className="text-2xl font-bold text-muted-foreground">Produto não encontrado</h2>
        <Link href="/produtos">
          <Button variant="outline">Voltar para Loja</Button>
        </Link>
      </div>
    );
  }

  const priceFormatted = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(product.price / 100);

  return (
    <div className="min-h-screen py-12 bg-background">
      <div className="container mx-auto px-4">
        <Link href="/produtos" className="inline-flex items-center text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Voltar para lista
        </Link>
        
        <div className="bg-white rounded-[2.5rem] p-6 md:p-12 border border-border shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div className="rounded-3xl overflow-hidden bg-muted aspect-square border-4 border-white shadow-lg flex items-center justify-center">
              <img 
                src={product.imageUrl} 
                alt={product.title}
                className="w-full h-full object-contain"
              />
            </div>
            
            <div className="flex flex-col h-full justify-center">
              <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary font-bold text-sm w-fit mb-4">
                Material Digital
              </span>
              
              <h1 className="font-display text-4xl md:text-5xl font-bold mb-6 text-foreground">
                {product.title}
              </h1>
              
              <div className="text-3xl font-bold text-primary mb-8">
                {priceFormatted}
              </div>
              
              <div className="prose prose-lg text-muted-foreground mb-8">
                <p>{product.description}</p>
              </div>
              
              <div className="space-y-4 mb-8">
                <h3 className="font-bold text-foreground">O que está incluído:</h3>
                <ul className="space-y-2">
                  <li className="flex items-center text-muted-foreground">
                    <Check className="w-5 h-5 text-green-500 mr-3" /> Arquivo PDF pronto para imprimir
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Check className="w-5 h-5 text-green-500 mr-3" /> Guia do Professor/Pais
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Check className="w-5 h-5 text-green-500 mr-3" /> Acesso vitalício ao material
                  </li>
                </ul>
              </div>
              
              {product.buyUrl ? (
                <a href={product.buyUrl} target="_blank" rel="noopener noreferrer">
                  <Button 
                    size="lg" 
                    className="w-full md:w-auto text-xl py-8 rounded-2xl bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold shadow-xl shadow-secondary/20"
                  >
                    <ShoppingBag className="mr-3 w-6 h-6" /> Comprar Agora
                  </Button>
                </a>
              ) : (
                <Button 
                  size="lg" 
                  className="w-full md:w-auto text-xl py-8 rounded-2xl bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold shadow-xl shadow-secondary/20"
                  onClick={() => alert("Compra indisponível no momento.")}
                >
                  <ShoppingBag className="mr-3 w-6 h-6" /> Comprar Agora
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
