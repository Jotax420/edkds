import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useProducts } from "@/hooks/use-products";
import { useReviews } from "@/hooks/use-reviews";
import { ProductCard } from "@/components/ProductCard";
import { Star, CheckCircle2, Heart, Puzzle, Users } from "lucide-react";
import heroImg from "@assets/generated_images/kids-playing-word-game.png"; // Placeholder path

export default function Home() {
  const { data: products } = useProducts();
  const { data: reviews } = useReviews();

  const featuredProducts = products?.slice(0, 3);

  const benefits = [
    {
      icon: <Puzzle className="w-8 h-8 text-primary" />,
      title: "Aprender Brincando",
      desc: "Jogos dinâmicos que ensinam regras ortográficas sem tédio."
    },
    {
      icon: <Heart className="w-8 h-8 text-secondary-foreground" />,
      title: "Foco na Confiança",
      desc: "Atividades que celebram o acerto e constroem autoestima."
    },
    {
      icon: <Users className="w-8 h-8 text-accent" />,
      title: "Para Pais e Professores",
      desc: "Material pronto para imprimir e usar em casa ou na sala de aula."
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background pt-12 pb-24 md:pt-24 md:pb-32">
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex-1 text-center md:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent font-bold text-sm mb-6">
                  ✨ Método Comprovado
                </span>
                <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
                  Ortografia sem <br />
                  <span className="text-primary relative inline-block">
                    Drama
                    <svg className="absolute w-full h-3 -bottom-1 left-0 text-secondary" viewBox="0 0 100 10" preserveAspectRatio="none">
                      <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
                    </svg>
                  </span>, só <span className="text-secondary font-hand text-6xl md:text-7xl lg:text-8xl transform rotate-2 inline-block ml-2">Diversão!</span>
                </h1>
                <p className="text-xl text-muted-foreground mb-8 max-w-lg mx-auto md:mx-0 leading-relaxed">
                  Transforme a hora de estudar em um momento de conexão e alegria com nossas dinâmicas exclusivas.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                  <Link href="/produtos">
                    <Button size="lg" className="text-lg px-8 py-6 rounded-full bg-primary hover:bg-primary/90 shadow-xl shadow-primary/25 hover:-translate-y-1 transition-all">
                      Ver Materiais
                    </Button>
                  </Link>
                  <Link href="/sobre">
                    <Button variant="outline" size="lg" className="text-lg px-8 py-6 rounded-full border-2 hover:bg-muted/50">
                      Como Funciona
                    </Button>
                  </Link>
                </div>
              </motion.div>
            </div>
            
            <div className="flex-1 relative">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="relative z-10"
              >
                {/* Image Placeholder - use Unsplash since assets might not exist yet */}
                {/* cheerful child learning spelling */}
                <div className="rounded-[2.5rem] overflow-hidden shadow-2xl border-8 border-white transform rotate-3 hover:rotate-0 transition-all duration-500">
                  <img 
                    src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=2022&auto=format&fit=crop" 
                    alt="Criança aprendendo feliz"
                    className="w-full h-auto object-cover"
                  />
                </div>
                
                {/* Decorative Elements */}
                <div className="absolute -top-8 -right-8 w-24 h-24 bg-secondary rounded-full blur-2xl opacity-50 animate-pulse" />
                <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-primary rounded-full blur-2xl opacity-50 animate-pulse delay-700" />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-display text-4xl font-bold mb-4">Por que as crianças amam?</h2>
            <p className="text-muted-foreground text-lg">Nosso método foge do tradicional "decoreba" e traz o lúdico para o centro do aprendizado.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {benefits.map((benefit, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-background rounded-3xl p-8 border border-border shadow-sm hover:shadow-md transition-shadow text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                  {benefit.icon}
                </div>
                <h3 className="font-display text-xl font-bold mb-3">{benefit.title}</h3>
                <p className="text-muted-foreground">{benefit.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-display text-4xl font-bold mb-2">Materiais em Destaque</h2>
              <p className="text-muted-foreground text-lg">Os favoritos dos professores e pais.</p>
            </div>
            <Link href="/produtos" className="hidden md:block">
              <Button variant="ghost" className="text-primary hover:text-primary/80 font-bold text-lg">
                Ver tudo <span className="ml-2">→</span>
              </Button>
            </Link>
          </div>

          {products ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">Carregando produtos maravilhosos...</div>
          )}

          <div className="mt-12 text-center md:hidden">
            <Link href="/produtos">
              <Button className="w-full bg-secondary text-secondary-foreground font-bold py-6 rounded-xl">
                Ver todos os materiais
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-primary overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2 text-primary-foreground">
              <h2 className="font-display text-4xl font-bold mb-6">Aprendizado na Prática</h2>
              <p className="text-xl opacity-90 mb-8 leading-relaxed">
                Veja como nossas dinâmicas transformam a sala de aula em um ambiente de descoberta e colaboração. Crianças engajadas aprendem mais rápido!
              </p>
              <ul className="space-y-4 mb-8">
                {["Estimula a memória visual", "Fortalece o trabalho em equipe", "Desenvolve a consciência fonológica"].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 font-medium">
                    <div className="bg-white/20 p-1 rounded-full">
                      <CheckCircle2 className="w-5 h-5 text-secondary" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
              <Button className="bg-white text-primary hover:bg-white/90 font-bold rounded-full px-8 py-6 text-lg shadow-lg">
                Conheça a Metodologia
              </Button>
            </div>
            <div className="md:w-1/2 grid grid-cols-2 gap-4">
              {/* classroom learning spelling */}
              <img 
                src="https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=1000&auto=format&fit=crop" 
                alt="Aula divertida"
                className="rounded-3xl shadow-lg transform translate-y-8" 
              />
              {/* teacher helping student */}
              <img 
                src="https://images.unsplash.com/photo-1544717305-2782549b5136?q=80&w=1000&auto=format&fit=crop" 
                alt="Professora ajudando"
                className="rounded-3xl shadow-lg transform -translate-y-8" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl font-bold text-center mb-16">O que dizem sobre nós</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews?.map((review) => (
              <motion.div 
                key={review.id}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-3xl border border-border shadow-sm relative"
              >
                <div className="absolute -top-4 left-8 bg-secondary text-secondary-foreground px-4 py-1 rounded-full text-sm font-bold shadow-sm">
                  {review.role}
                </div>
                <div className="flex gap-1 mb-4 text-secondary">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="fill-current w-5 h-5" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 italic">"{review.content}"</p>
                <div className="font-bold text-lg">{review.name}</div>
              </motion.div>
            ))}
            {(!reviews || reviews.length === 0) && (
              <div className="col-span-3 text-center text-muted-foreground">
                <p>Nossas avaliações estão sendo carregadas...</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-foreground rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div className="relative z-10 max-w-2xl mx-auto">
              <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
                Pronto para revolucionar a ortografia?
              </h2>
              <p className="text-gray-300 text-xl mb-10">
                Junte-se a centenas de professores e pais que já transformaram o aprendizado das crianças.
              </p>
              <Link href="/produtos">
                <Button size="lg" className="text-xl px-12 py-8 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold shadow-2xl hover:scale-105 transition-transform">
                  Começar Agora
                </Button>
              </Link>
            </div>
            
            {/* Background Decorations */}
            <div className="absolute top-0 left-0 w-64 h-64 bg-primary/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-64 h-64 bg-accent/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
          </div>
        </div>
      </section>
    </div>
  );
}
