## Packages
framer-motion | Animations for page transitions and scroll reveals
lucide-react | Icons for UI elements
react-hook-form | Form handling for contact and orders
zod | Schema validation for forms
@hookform/resolvers | Zod resolver for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  hand: ["var(--font-hand)"],
}
