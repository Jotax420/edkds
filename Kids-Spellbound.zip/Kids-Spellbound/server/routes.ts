import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Products
  app.get(api.products.list.path, async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  // Reviews
  app.get(api.reviews.list.path, async (req, res) => {
    const reviews = await storage.getReviews();
    res.json(reviews);
  });

  // Messages
  app.post(api.messages.create.path, async (req, res) => {
    try {
      const input = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(input);
      res.status(201).json(message);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingProducts = await storage.getProducts();
  if (existingProducts.length === 0) {
    await storage.createProduct({
      title: "+300 ATIVIDADES E DINÂMICAS PARA EDUCAÇÃO INFANTIL COM FLASH CARDS E CHECKLIST DE EVOLUÇÃO",
      description: `🎓 CONTEÚDO COMPLETO:
✓ Tudo do Kit Básico
🎁 Bônus: 50 Flashcards Visuais
🎁 Bônus: Checklist de Evolução
🎁 Bônus: Alfabeto de Parede Lúdico
🎁 Painel de Palavra Avançado
🎁 Múltiplos Bônus Surpresa
✓ Suporte Prioritário
✓ Atualizações Gratuitas

O kit mais completo para educadores que querem potencializar o aprendizado de crianças de forma lúdica e estruturada!`,
      price: 1997, // R$ 19,97 em centavos
      imageUrl: "/images/atividades-300.png",
      buyUrl: "https://pay.cakto.com.br/anmaphx_695310",
    });
    await storage.createProduct({
      title: "+200 DINÂMICAS DE ORTOGRAFIA + PAINEL DE PALAVRAS + BÔNUS",
      description: `📚 CONTEÚDO COMPLETO:
✓ 200 Dinâmicas de Ortografia
✓ PDF de Alta Qualidade
✓ Acesso Vitalício
✓ Download Imediato
🎁 Painel de Palavra Grátis
🎁 Bônus Surpresa Exclusivo

Material perfeito para pais e professores que querem transformar o aprendizado de ortografia em uma experiência divertida e eficaz!`,
      price: 1000, // R$ 10,00 em centavos
      imageUrl: "/images/dinamicas-200.png",
      buyUrl: "https://pay.cakto.com.br/3dc7m4t_695232",
    });
  }

  const existingReviews = await storage.getReviews();
  if (existingReviews.length === 0) {
    await storage.createReview({
      name: "Mariana Silva",
      rating: 5,
      content: "Minha filha adorou os jogos! Ela aprendeu brincando e as notas na escola melhoraram muito.",
      role: "Mãe",
    });
    await storage.createReview({
      name: "Prof. Carlos",
      rating: 5,
      content: "Material excelente para usar em sala de aula. Os alunos ficam muito engajados com as dinâmicas.",
      role: "Professor",
    });
    await storage.createReview({
      name: "Ana Souza",
      rating: 4,
      content: "Muito criativo e bem ilustrado. Recomendo para pais que querem ajudar os filhos em casa.",
      role: "Pedagoga",
    });
  }
}
